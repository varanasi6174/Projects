package Project.MavenEg.dao;

//crud method
public interface EmployeeDao {
	
     public void addEmp();
     
     public void updateEmp();
     
     public void deleteEmp();
     
     public void readEmp();
}
