package Project.MavenEg.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity // marks the class as entity
@Table(name="EmpDetails")  //specifies the table name
public class Employee {
	
	@Id //marks it as identifier for this entity
	@GeneratedValue(strategy = GenerationType.AUTO)
   private int empid;
	
	@Column( name="FiretName", length=30, nullable = false)
   private String empname;
	
	@Column(length=30)
   private String empsurname;
	
	@Column(length=11, nullable = false, unique = true)
   private long empphone;
	
	@Column(length=40)
   private String empaddr;
	
	@Column(length=20, nullable = false)
	private String designation;
   
   
   
   public Employee(int empid, String empname, String empsurname, long empphone, String empaddr, String designation) {
	super();
	this.empid = empid;
	this.empname = empname;
	this.empsurname = empsurname;
	this.empphone = empphone;
	this.empaddr = empaddr;
	this.designation = designation;
}
public Employee() {
	super();
}
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getEmpsurname() {
	return empsurname;
}
public void setEmpsurname(String empsurname) {
	this.empsurname = empsurname;
}
public long getEmpphone() {
	return empphone;
}
public void setEmpphone(long empphone) {
	this.empphone = empphone;
}
public String getEmpaddr() {
	return empaddr;
}
public void setEmpaddr(String empaddr) {
	this.empaddr = empaddr;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}

}
