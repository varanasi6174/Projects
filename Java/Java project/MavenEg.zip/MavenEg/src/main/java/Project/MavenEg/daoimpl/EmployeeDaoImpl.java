package Project.MavenEg.daoimpl;

import java.util.Scanner;

import org.hibernate.Session;

import Project.MavenEg.config.Hibernateutil;
import Project.MavenEg.dao.EmployeeDao;
import Project.MavenEg.entity.Employee;
import jakarta.transaction.Transaction;

public class EmployeeDaoImpl implements EmployeeDao {
   
	Scanner sc = new Scanner(System.in);
	
	public void addEmp() {
	try {
		Session session = Hibernateutil.getSessionFactory().openSession();
		Transaction t = (Transaction) session.beginTransaction();
		String empname, empsurname, empaddr, designation;
		long empphone;
		System.out.println("Enter name");
		empname = sc.next();
		System.out.println("Enter surname");
		empsurname = sc.next();
		System.out.println("Enter phone no");
		empphone = sc.nextLong();
		System.out.println("Enter address");
		empaddr = sc.next();
		System.out.println("Enter designation");
		designation= sc.next();
		
		Employee e = new Employee();
		e.setEmpname(empname);
		e.setEmpsurname(empsurname);
		e.setEmpphone(empphone);
		e.setEmpaddr(empaddr);
		e.setDesignation(designation);
		
		session.save(e);
		t.commit();
		System.out.println(e);
		
		session.close();
		
	}catch (Exception e) {
		System.out.println(e);
	}
		
	}

	public void updateEmp() {
		try {
			
		}catch (Exception e) {
			System.out.println(e);
		}
		
	}

	public void deleteEmp() {
		try {
			
		}catch (Exception e) {
			System.out.println(e);
		}
		
	}

	public void readEmp() {
		try {
			
		}catch (Exception e) {
			System.out.println(e);
		}
		
	}

}
