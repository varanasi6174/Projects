package com.springrest.springrest.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.springrest.springrest.entity.Course;
import com.springrest.springrest.service.CourseService;
 
@Service
public class CourseServiceImpl implements CourseService{

	List<Course> list;
	public CourseServiceImpl() {
		
		list=new ArrayList<>();
		list.add(new Course(145, "Java Core Course", "This course contain basic of java"));
		list.add(new Course(146, "Spring Boot", "Creating rest api using spring boot"));
		
	}
	
	@Override
	public List<Course> getCourses() {
		return list;
	}

	@Override
	public Course getCourse(long courseId) {
		Course c=null;
		for(Course course:list) {
			if(course.getId()==courseId) {
			c=course;
			break;
			}
		}
		return c;
	}

}











