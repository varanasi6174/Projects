package com.anudip.sb.service;

import com.anudip.sb.entity.Login;

public interface LoginService {

	Login loginUser(String userName, String password);

}
