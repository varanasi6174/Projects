package com.anudip.sb.exception;

public class TeacherIdNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public TeacherIdNotFoundException(String message) {
		super(message);
		
	}
	
	
}
