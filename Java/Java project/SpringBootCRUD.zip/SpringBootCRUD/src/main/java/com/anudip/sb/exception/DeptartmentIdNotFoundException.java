package com.anudip.sb.exception;

public class DeptartmentIdNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public DeptartmentIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}

