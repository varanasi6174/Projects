package com.anudip.sb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anudip.sb.entity.Courses;

public interface CourseRepository extends JpaRepository<Courses, Integer>{

}
