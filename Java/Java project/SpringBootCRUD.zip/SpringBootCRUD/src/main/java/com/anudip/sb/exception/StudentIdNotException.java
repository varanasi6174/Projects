package com.anudip.sb.exception;

public class StudentIdNotException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public StudentIdNotException(String message) {
		super(message);
		
	}
	
	

}
